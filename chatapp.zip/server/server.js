const express = require('express');
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { WebSocketServer } = require('ws');
let mm = null;
try { mm = require('music-metadata'); } catch (_) { console.warn('music-metadata نصب نیست؛ متادیتای آهنگ خوانده نمی‌شود (npm install)'); }

const PORT = process.env.PORT || 3000;
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'data.json');
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, 'uploads');
const FILES_DIR = process.env.FILES_DIR || path.join(__dirname, 'files');
const MAX_FILE = 30 * 1024 * 1024; // ۳۰ مگابایت
const SECRET_FILE = path.join(__dirname, '.secret');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
fs.mkdirSync(FILES_DIR, { recursive: true });

// ---- JWT secret (از env یا فایل ذخیره‌شده) ----
let SECRET = process.env.JWT_SECRET;
if (!SECRET) {
  if (fs.existsSync(SECRET_FILE)) {
    SECRET = fs.readFileSync(SECRET_FILE, 'utf8').trim();
  } else {
    SECRET = crypto.randomBytes(48).toString('hex');
    fs.writeFileSync(SECRET_FILE, SECRET, { mode: 0o600 });
  }
}

// ---- ذخیره‌سازی ساده در فایل JSON ----
let db = { users: [], messages: [], nextUserId: 1, nextMsgId: 1, adminCodes: [], adminSeeded: false, lotties: [] };
if (fs.existsSync(DATA_FILE)) {
  try {
    db = Object.assign(db, JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')));
  } catch (e) {
    console.error('خواندن data.json ناموفق بود:', e.message);
    process.exit(1);
  }
}
// ---- مهاجرت: آواتار تکی -> آرایه‌ی عکس‌های پروفایل ----
const MAX_PHOTOS = 10;
function syncAvatar(u) {
  u.avatar = u.photos && u.photos[0] ? u.photos[0].url : null;
}
for (const u of db.users) {
  if (!Array.isArray(u.photos)) {
    u.photos = u.avatar ? [{ id: 'p' + crypto.randomBytes(5).toString('hex'), url: u.avatar }] : [];
  }
  syncAvatar(u);
}
// ---- ادمین: کدهای یک‌بارمصرف (فقط هششون ذخیره میشه) ----
const ADMIN_PREFIX = 'admin(pass)';
const hashCode = (c) => crypto.createHash('sha256').update(String(c)).digest('hex');
if (!Array.isArray(db.adminCodes)) db.adminCodes = [];
// کد اولیه فقط یک بار ساخته میشه؛ بعد از مصرف دیگه دوباره ساخته نمیشه.
// برای عوض کردنش: متغیر محیطی ADMIN_SEED_CODE
if (!db.adminSeeded) {
  const seed = process.env.ADMIN_SEED_CODE || 'admin(pass)user!82';
  db.adminCodes.push({ id: 'c' + crypto.randomBytes(5).toString('hex'), hash: hashCode(seed), createdBy: null, createdAt: Date.now() });
  db.adminSeeded = true;
  try { fs.writeFileSync(DATA_FILE, JSON.stringify(db)); } catch (_) {}
}
let saveTimer = null;
function save() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    const tmp = DATA_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db));
    fs.renameSync(tmp, DATA_FILE);
  }, 200);
}
process.on('SIGINT', () => {
  try { fs.writeFileSync(DATA_FILE, JSON.stringify(db)); } catch (_) {}
  process.exit(0);
});

// ---- WebSocket sockets ----
const sockets = new Map(); // userId -> Set<ws>
function push(uid, payload) {
  const set = sockets.get(uid);
  if (!set) return;
  const s = JSON.stringify(payload);
  for (const ws of set) if (ws.readyState === 1) ws.send(s);
}
function pushBoth(m, payload) {
  push(m.from, payload);
  if (m.to !== m.from) push(m.to, payload);
}
function broadcast(payload) {
  const s = JSON.stringify(payload);
  for (const set of sockets.values()) for (const ws of set) if (ws.readyState === 1) ws.send(s);
}

// ---- ابزارها ----
const USERNAME_RE = /^[A-Za-z0-9_]{3,32}$/;
const publicUser = (u) => ({
  id: u.id,
  username: u.username,
  firstName: u.firstName || '',
  lastName: u.lastName || '',
  bio: u.bio || '',
  avatar: u.avatar || null,
  photos: (u.photos || []).map((p) => ({ id: p.id, url: p.url })),
  music: u.music ? publicMusic(u) : null,
  online: sockets.has(u.id),
  lastSeen: u.lastSeen || u.createdAt || 0,
  isAdmin: !!u.isAdmin,
});
const publicMusic = (u) => ({
  name: u.music.name,
  size: u.music.size,
  mime: u.music.mime,
  kind: 'audio',
  url: '/users/' + u.id + '/music/' + u.music.stored.split('.')[0],
  meta: u.music.meta || null,
});
const publicMsg = (m, withThumb = false) => ({
  id: m.id,
  from: m.from,
  to: m.to,
  text: m.text,
  createdAt: m.createdAt,
  read: !!m.read,
  edited: !!m.edited,
  pinned: !!m.pinned,
  file: m.file ? publicFile(m, withThumb) : null,
  reply: m.replyTo ? replyInfo(m.replyTo) : null,
  reactions: m.reactions || {},
});
// خلاصه‌ی پیامی که بهش ریپلای شده
const replyInfo = (id) => {
  const r = db.messages.find((x) => x.id === id);
  if (!r) return { id, from: null, text: 'Deleted message' };
  let text = (r.text || '').trim();
  if (r.file) {
    const k = r.file.kind;
    const label = k === 'audio' ? '🎵 ' + ((r.file.meta && r.file.meta.title) || r.file.name)
      : k === 'voice' ? '🎤 Voice message' : k === 'round' ? '📹 Video message'
      : k === 'image' ? '🖼 Photo' : k === 'video' ? '🎬 Video' : '📎 ' + r.file.name;
    text = text ? label + '  ' + text : label;
  }
  return { id: r.id, from: r.from, text: text.slice(0, 200) };
};
// ری‌اکشن‌های مجاز
const REACTIONS = ['❤️', '💘', '💔', '😂', '😐', '😑', '🗿', '😭', '👾'];
const normEmoji = (e) => String(e || '').replace(/\uFE0F/g, '');
// پیام مقصدِ ریپلای باید تو همین گفتگو باشه
const validReply = (v, me, peer) => {
  const id = parseInt(v, 10);
  if (!id) return null;
  const r = db.messages.find((x) => x.id === id);
  if (!r) return null;
  const ok = (r.from === me && r.to === peer) || (r.from === peer && r.to === me);
  return ok ? id : null;
};
const publicFile = (m, withThumb = false) => {
  const o = {
    name: m.file.name,
    size: m.file.size,
    mime: m.file.mime,
    kind: m.file.kind, // audio | voice | image | video | gif | round | file
    url: '/file/' + m.id,
    meta: m.file.meta || null, // برای آهنگ: title, artist, album, duration, cover
  };
  // پیش‌نمایش ریز (base64 JPEG) فقط برای لیست گفتگوها فرستاده میشه
  if (withThumb && m.file.thumb) o.thumb = m.file.thumb;
  return o;
};
const visibleTo = (m, me) => !(m.hiddenFor || []).includes(me);
const sign = (u) => jwt.sign({ uid: u.id }, SECRET, { expiresIn: '90d' });

function removeAvatarFile(rel) {
  if (typeof rel !== 'string' || !rel.startsWith('/uploads/')) return;
  try { fs.unlinkSync(path.join(UPLOAD_DIR, path.basename(rel))); } catch (_) {}
}

const EXT_KIND = {
  mp3: ['audio', 'audio/mpeg'], m4a: ['audio', 'audio/mp4'], aac: ['audio', 'audio/aac'],
  ogg: ['audio', 'audio/ogg'], oga: ['audio', 'audio/ogg'], opus: ['audio', 'audio/ogg'],
  wav: ['audio', 'audio/wav'], flac: ['audio', 'audio/flac'], wma: ['audio', 'audio/x-ms-wma'],
  jpg: ['image', 'image/jpeg'], jpeg: ['image', 'image/jpeg'], png: ['image', 'image/png'],
  webp: ['image', 'image/webp'], gif: ['image', 'image/gif'],
  mp4: ['video', 'video/mp4'], mkv: ['video', 'video/x-matroska'], webm: ['video', 'video/webm'],
  mov: ['video', 'video/quicktime'], '3gp': ['video', 'video/3gpp'],
};
function classify(name, mimeHeader) {
  const ext = path.extname(name).slice(1).toLowerCase();
  const byExt = EXT_KIND[ext];
  let mime = /^[\w.+-]+\/[\w.+-]+$/.test(mimeHeader || '') ? mimeHeader.toLowerCase() : '';
  if (!mime || mime === 'application/octet-stream') mime = byExt ? byExt[1] : 'application/octet-stream';
  let kind = 'file';
  if (mime.startsWith('audio/')) kind = 'audio';
  else if (mime.startsWith('image/')) kind = 'image';
  else if (mime.startsWith('video/')) kind = 'video';
  else if (byExt) kind = byExt[0];
  return { kind, mime };
}
function safeName(n) {
  n = String(n || 'file').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').trim();
  return n.slice(-120) || 'file';
}
function removeMsgFile(m) {
  if (!m || !m.file) return;
  try { fs.unlinkSync(path.join(FILES_DIR, m.file.stored)); } catch (_) {}
  if (m.file.meta && m.file.meta.cover) removeAvatarFile(m.file.meta.cover);
}
async function readAudioMeta(full, id) {
  if (!mm) return null;
  try {
    const md = await mm.parseFile(full, { duration: true, skipPostHeaders: true });
    const c = md.common || {};
    const meta = {
      title: c.title || null,
      artist: c.artist || (c.artists && c.artists[0]) || null,
      album: c.album || null,
      year: c.year || null,
      duration: md.format && md.format.duration ? Math.round(md.format.duration * 1000) : null,
      cover: null,
    };
    const pic = c.picture && c.picture[0];
    if (pic && pic.data && pic.data.length < 2 * 1024 * 1024) {
      const f = String(pic.format || '').toLowerCase();
      const ext = f.includes('png') ? 'png' : (f.includes('webp') ? 'webp' : 'jpg');
      const name = `cover_${id}.${ext}`;
      fs.writeFileSync(path.join(UPLOAD_DIR, name), pic.data);
      meta.cover = '/uploads/' + name;
    }
    return meta;
  } catch (e) {
    console.warn('metadata error:', e.message);
    return null;
  }
}

// محدودیت ساده تعداد تلاش ورود/ثبت‌نام (۲۰ بار در ۱۰ دقیقه برای هر IP)
const attempts = new Map();
function limiter(req, res, next) {
  const ip = req.ip;
  const now = Date.now();
  const list = (attempts.get(ip) || []).filter((t) => now - t < 10 * 60 * 1000);
  if (list.length >= 20) return res.status(429).json({ error: 'تعداد تلاش‌ها زیاد است، چند دقیقه بعد دوباره امتحان کنید' });
  list.push(now);
  attempts.set(ip, list);
  next();
}

function auth(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : String(req.query.token || '');
  try {
    const p = jwt.verify(token, SECRET);
    const u = db.users.find((x) => x.id === p.uid);
    if (!u) throw new Error('no user');
    if (!Array.isArray(u.photos)) u.photos = [];
    req.user = u;
    next();
  } catch (_) {
    res.status(401).json({ error: 'unauthorized' });
  }
}

// ---- REST ----
const app = express();
app.set('trust proxy', true);
app.use('/uploads', express.static(UPLOAD_DIR, { maxAge: '30d', immutable: true }));
app.use((req, res, next) =>
  express.json({ limit: (req.path === '/me/avatar' || req.path === '/me/photos') ? '3mb' : (req.path === '/packs/draft/item' ? '2gb' : (req.path === '/admin/lotties' ? '6mb' : '20kb')) })(req, res, next));

app.get('/', (_req, res) => res.json({ ok: true, name: 'chat-server' }));

app.post('/register', limiter, async (req, res) => {
  const { username, password } = req.body || {};
  if (typeof username !== 'string' || !USERNAME_RE.test(username))
    return res.status(400).json({ error: 'نام کاربری باید ۳ تا ۳۲ حرف انگلیسی، عدد یا _ باشد' });
  if (typeof password !== 'string' || password.length < 6 || password.length > 100)
    return res.status(400).json({ error: 'رمز عبور حداقل ۶ کاراکتر باشد' });

  const hash = await bcrypt.hash(password, 10);
  const key = username.toLowerCase();
  if (db.users.some((u) => u.key === key))
    return res.status(409).json({ error: 'این نام کاربری قبلاً گرفته شده' });

  const user = { id: db.nextUserId++, username, key, hash, firstName: '', lastName: '', bio: '', avatar: null, photos: [], music: null, createdAt: Date.now(), lastSeen: Date.now() };
  db.users.push(user);
  save();
  res.json({ token: sign(user), user: publicUser(user) });
});

app.post('/login', limiter, async (req, res) => {
  const { username, password } = req.body || {};
  if (typeof username !== 'string' || typeof password !== 'string')
    return res.status(400).json({ error: 'نام کاربری و رمز عبور را وارد کنید' });
  const user = db.users.find((u) => u.key === username.trim().toLowerCase());
  const ok = user && (await bcrypt.compare(password, user.hash));
  if (!ok) return res.status(401).json({ error: 'نام کاربری یا رمز عبور اشتباه است' });
  res.json({ token: sign(user), user: publicUser(user) });
});

// ---- پروفایل ----
app.get('/me', auth, (req, res) => res.json(publicUser(req.user)));

app.patch('/me', auth, (req, res) => {
  const { username, bio, firstName, lastName } = req.body || {};
  const u = req.user;
  let newName = null;
  let newBio = null;
  let newFirst = null;
  let newLast = null;
  for (const [val, label] of [[firstName, 'First name'], [lastName, 'Last name']]) {
    if (val === undefined) continue;
    if (typeof val !== 'string' || val.trim().length > 40)
      return res.status(400).json({ error: label + ' must be at most 40 characters' });
  }
  if (firstName !== undefined) newFirst = firstName.trim().replace(/\s+/g, ' ');
  if (lastName !== undefined) newLast = lastName.trim().replace(/\s+/g, ' ');
  if (username !== undefined) {
    if (typeof username !== 'string' || !USERNAME_RE.test(username))
      return res.status(400).json({ error: 'نام کاربری باید ۳ تا ۳۲ حرف انگلیسی، عدد یا _ باشد' });
    const key = username.toLowerCase();
    if (db.users.some((x) => x.key === key && x.id !== u.id))
      return res.status(409).json({ error: 'این نام کاربری قبلاً گرفته شده' });
    newName = username;
  }
  if (bio !== undefined) {
    if (typeof bio !== 'string' || bio.trim().length > 200)
      return res.status(400).json({ error: 'Bio must be at most 200 characters' });
    newBio = bio.trim();
  }
  if (newName !== null) { u.username = newName; u.key = newName.toLowerCase(); }
  if (newBio !== null) u.bio = newBio;
  if (newFirst !== null) u.firstName = newFirst;
  if (newLast !== null) u.lastName = newLast;
  save();
  const out = publicUser(u);
  broadcast({ type: 'user', user: out });
  res.json(out);
});

function addPhoto(req, res) {
  const b64 = req.body && req.body.data;
  if (typeof b64 !== 'string' || !b64) return res.status(400).json({ error: 'Invalid image' });
  const buf = Buffer.from(b64, 'base64');
  if (buf.length < 100) return res.status(400).json({ error: 'Invalid image' });
  if (buf.length > 2 * 1024 * 1024) return res.status(413).json({ error: 'Image too large' });
  let ext = null;
  if (buf[0] === 0xff && buf[1] === 0xd8) ext = 'jpg';
  else if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) ext = 'png';
  else if (buf.subarray(0, 4).toString() === 'RIFF' && buf.subarray(8, 12).toString() === 'WEBP') ext = 'webp';
  if (!ext) return res.status(400).json({ error: 'Invalid image' });

  const u = req.user;
  if (u.photos.length >= MAX_PHOTOS) return res.status(400).json({ error: 'You can have up to ' + MAX_PHOTOS + ' profile photos' });
  const name = `u${u.id}_${Date.now()}_${crypto.randomBytes(3).toString('hex')}.${ext}`;
  fs.writeFileSync(path.join(UPLOAD_DIR, name), buf);
  // عکس جدید میشه عکس اصلی (اول لیست)
  u.photos.unshift({ id: 'p' + crypto.randomBytes(5).toString('hex'), url: '/uploads/' + name });
  syncAvatar(u);
  save();
  const out = publicUser(u);
  broadcast({ type: 'user', user: out });
  res.json(out);
}
app.post('/me/avatar', auth, addPhoto);
app.post('/me/photos', auth, addPhoto);

// حذف عکس اصلی (سازگار با نسخه‌ی قبلی)
app.delete('/me/avatar', auth, (req, res) => {
  const u = req.user;
  const p = u.photos.shift();
  if (p) removeAvatarFile(p.url);
  syncAvatar(u);
  save();
  const out = publicUser(u);
  broadcast({ type: 'user', user: out });
  res.json(out);
});

app.delete('/me/photos/:id', auth, (req, res) => {
  const u = req.user;
  const i = u.photos.findIndex((p) => p.id === req.params.id);
  if (i < 0) return res.status(404).json({ error: 'Photo not found' });
  const [p] = u.photos.splice(i, 1);
  removeAvatarFile(p.url);
  syncAvatar(u);
  save();
  const out = publicUser(u);
  broadcast({ type: 'user', user: out });
  res.json(out);
});

// عکس انتخاب‌شده بشه عکس اصلی
app.post('/me/photos/:id/main', auth, (req, res) => {
  const u = req.user;
  const i = u.photos.findIndex((p) => p.id === req.params.id);
  if (i < 0) return res.status(404).json({ error: 'Photo not found' });
  const [p] = u.photos.splice(i, 1);
  u.photos.unshift(p);
  syncAvatar(u);
  save();
  const out = publicUser(u);
  broadcast({ type: 'user', user: out });
  res.json(out);
});

// ---- آهنگ پروفایل ----
function removeMusicFiles(music) {
  if (!music) return;
  try { fs.unlinkSync(path.join(FILES_DIR, music.stored)); } catch (_) {}
  if (music.meta && music.meta.cover) removeAvatarFile(music.meta.cover);
}

// کپی فایل آهنگ (و کاورش) تا اگه پیام اصلی پاک شد آهنگ پروفایل سالم بمونه
function cloneMusic(src) {
  const id = crypto.randomBytes(16).toString('hex');
  const ext = path.extname(src.stored);
  const stored = id + ext;
  fs.copyFileSync(path.join(FILES_DIR, src.stored), path.join(FILES_DIR, stored));
  const meta = src.meta ? Object.assign({}, src.meta) : null;
  if (meta && meta.cover) {
    try {
      const cext = path.extname(meta.cover);
      const cname = `cover_${id}${cext}`;
      fs.copyFileSync(path.join(UPLOAD_DIR, path.basename(meta.cover)), path.join(UPLOAD_DIR, cname));
      meta.cover = '/uploads/' + cname;
    } catch (_) { meta.cover = null; }
  }
  return { name: src.name, size: src.size, mime: src.mime, stored, meta };
}

function setMusic(u, music, res) {
  removeMusicFiles(u.music);
  u.music = music;
  save();
  const out = publicUser(u);
  broadcast({ type: 'user', user: out });
  res.json(out);
}

// از یک آهنگ موجود: {messageId} یا {userId} (آهنگ پروفایل یه کاربر دیگه)
app.post('/me/music', auth, (req, res) => {
  const me = req.user.id;
  const { messageId, userId } = req.body || {};
  let src = null;
  if (messageId !== undefined) {
    const m = db.messages.find((x) => x.id === parseInt(messageId, 10));
    if (!m || (m.from !== me && m.to !== me) || !visibleTo(m, me) || !m.file)
      return res.status(404).json({ error: 'Message not found' });
    if (m.file.kind !== 'audio') return res.status(400).json({ error: 'Only audio files can be used' });
    src = m.file;
  } else if (userId !== undefined) {
    const o = db.users.find((x) => x.id === parseInt(userId, 10));
    if (!o || !o.music) return res.status(404).json({ error: 'Music not found' });
    src = o.music;
  } else {
    return res.status(400).json({ error: 'Invalid request' });
  }
  if (!fs.existsSync(path.join(FILES_DIR, src.stored))) return res.status(404).json({ error: 'File is gone' });
  try {
    setMusic(req.user, cloneMusic(src), res);
  } catch (e) {
    res.status(500).json({ error: 'Could not save music' });
  }
});

// آپلود مستقیم آهنگ برای پروفایل (بدنه = فایل، هدر x-file-name) تا ۳۰ مگ
app.post('/me/music/upload', auth, (req, res) => {
  const declared = parseInt(req.headers['content-length'] || '0', 10);
  if (declared > MAX_FILE) return res.status(413).json({ error: 'File is too large (max 30 MB)' });
  if (declared === 0 && !req.headers['transfer-encoding']) return res.status(400).json({ error: 'Empty file' });
  let name = String(req.headers['x-file-name'] || 'music');
  try { name = decodeURIComponent(name); } catch (_) {}
  name = safeName(name);
  const { kind, mime } = classify(name, '');
  if (kind !== 'audio') return res.status(400).json({ error: 'Only audio files can be used' });
  const id = crypto.randomBytes(16).toString('hex');
  const ext = path.extname(name).replace(/[^A-Za-z0-9.]/g, '').slice(0, 10);
  const stored = id + ext;
  const full = path.join(FILES_DIR, stored);
  const out = fs.createWriteStream(full);
  let size = 0;
  let failed = false;
  const fail = (code, msg) => {
    if (failed) return;
    failed = true;
    req.unpipe(out);
    out.destroy();
    fs.unlink(full, () => {});
    if (!res.headersSent) res.status(code).json({ error: msg });
    req.resume();
  };
  req.on('data', (c) => { size += c.length; if (size > MAX_FILE) fail(413, 'File is too large (max 30 MB)'); });
  req.on('aborted', () => fail(400, 'Upload aborted'));
  req.on('error', () => fail(400, 'Upload failed'));
  out.on('error', () => fail(500, 'Could not save file'));
  req.pipe(out);
  out.on('finish', async () => {
    if (failed) return;
    if (size === 0) { failed = true; fs.unlink(full, () => {}); return res.status(400).json({ error: 'Empty file' }); }
    const meta = await readAudioMeta(full, id);
    setMusic(req.user, { name, size, mime, stored, meta }, res);
  });
});

app.delete('/me/music', auth, (req, res) => {
  const u = req.user;
  removeMusicFiles(u.music);
  u.music = null;
  save();
  const out = publicUser(u);
  broadcast({ type: 'user', user: out });
  res.json(out);
});

// استریم آهنگ پروفایل (Range پشتیبانی میشه)
app.get('/users/:id/music/:v?', auth, (req, res) => {
  const u = db.users.find((x) => x.id === parseInt(req.params.id, 10));
  if (!u || !u.music) return res.status(404).json({ error: 'Music not found' });
  const full = path.join(FILES_DIR, u.music.stored);
  if (!fs.existsSync(full)) return res.status(404).json({ error: 'File is gone' });
  res.sendFile(full, {
    headers: {
      'Content-Type': u.music.mime,
      'Content-Disposition': `inline; filename*=UTF-8''${encodeURIComponent(u.music.name)}`,
      'Cache-Control': 'private, max-age=86400',
    },
  });
});

app.get('/users', auth, (req, res) => {
  const q = String(req.query.q || '').trim().toLowerCase();
  const list = db.users
    .filter((u) => u.id !== req.user.id && (!q || u.key.includes(q)))
    .slice(0, 30)
    .map(publicUser);
  res.json(list);
});

app.get('/users/:id', auth, (req, res) => {
  const u = db.users.find((x) => x.id === parseInt(req.params.id, 10));
  if (!u) return res.status(404).json({ error: 'کاربر پیدا نشد' });
  res.json(publicUser(u));
});

// ---- ادمین ----
function adminOnly(req, res, next) {
  if (!req.user.isAdmin) return res.status(403).json({ error: 'Forbidden' });
  next();
}
const adminCount = () => db.users.filter((u) => u.isAdmin).length;
const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
function newCode() {
  let r = '';
  const b = crypto.randomBytes(12);
  for (let i = 0; i < 12; i++) r += CODE_ALPHABET[b[i] % CODE_ALPHABET.length];
  return ADMIN_PREFIX + r;
}

// مصرف کد: اگه معتبر باشه کد پاک میشه و کاربر ادمین میشه
app.post('/admin/redeem', limiter, auth, (req, res) => {
  const code = typeof req.body?.code === 'string' ? req.body.code.trim() : '';
  if (!code || code.length > 100) return res.status(400).json({ error: 'Invalid or already used code' });
  if (req.user.isAdmin) return res.json({ alreadyAdmin: true, user: publicUser(req.user) });
  const h = hashCode(code);
  const i = db.adminCodes.findIndex((c) => c.hash === h);
  if (i < 0) return res.status(400).json({ error: 'Invalid or already used code' });
  db.adminCodes.splice(i, 1); // یک‌بارمصرف
  req.user.isAdmin = true;
  req.user.adminSince = Date.now();
  save();
  const out = publicUser(req.user);
  broadcast({ type: 'user', user: out });
  res.json({ alreadyAdmin: false, user: out });
});

// لیست همه‌ی کاربران با اطلاعات (فقط متادیتا؛ متن پیام‌ها هیچ‌وقت برگردونده نمیشه)
app.get('/admin/users', auth, adminOnly, (req, res) => {
  const q = String(req.query.q || '').trim().toLowerCase();
  const sent = new Map();
  const recv = new Map();
  for (const m of db.messages) {
    sent.set(m.from, (sent.get(m.from) || 0) + 1);
    recv.set(m.to, (recv.get(m.to) || 0) + 1);
  }
  const list = db.users
    .filter((u) => !q || u.key.includes(q))
    .map((u) => Object.assign(publicUser(u), {
      createdAt: u.createdAt || 0,
      adminSince: u.adminSince || null,
      sentCount: sent.get(u.id) || 0,
      receivedCount: recv.get(u.id) || 0,
    }));
  res.json(list);
});

// ساخت کد یک‌بارمصرف جدید (کد کامل فقط همین یک بار نشون داده میشه)
app.post('/admin/codes', auth, adminOnly, (req, res) => {
  const code = newCode();
  const entry = { id: 'c' + crypto.randomBytes(5).toString('hex'), hash: hashCode(code), createdBy: req.user.id, createdAt: Date.now() };
  db.adminCodes.push(entry);
  save();
  res.json({ id: entry.id, code, createdAt: entry.createdAt });
});

// کدهای مصرف‌نشده (بدون خود کد)
app.get('/admin/codes', auth, adminOnly, (req, res) => {
  res.json(db.adminCodes.map((c) => {
    const by = db.users.find((u) => u.id === c.createdBy);
    return { id: c.id, createdAt: c.createdAt, createdBy: by ? by.username : null };
  }));
});

app.delete('/admin/codes/:id', auth, adminOnly, (req, res) => {
  const i = db.adminCodes.findIndex((c) => c.id === req.params.id);
  if (i < 0) return res.status(404).json({ error: 'Code not found' });
  db.adminCodes.splice(i, 1);
  save();
  res.json({ ok: true });
});

// ادمین کردن / برداشتن ادمین یه کاربر
app.post('/admin/users/:id/admin', auth, adminOnly, (req, res) => {
  const u = db.users.find((x) => x.id === parseInt(req.params.id, 10));
  if (!u) return res.status(404).json({ error: 'User not found' });
  const on = req.body?.isAdmin !== false;
  if (!on) {
    if (u.id === req.user.id) return res.status(400).json({ error: 'You cannot remove your own admin access' });
    if (u.isAdmin && adminCount() <= 1) return res.status(400).json({ error: 'There must be at least one admin' });
  }
  u.isAdmin = on;
  if (on && !u.adminSince) u.adminSince = Date.now();
  save();
  const out = publicUser(u);
  broadcast({ type: 'user', user: out });
  res.json(out);
});


// ---- Lottie: ایموجی‌های متحرک (فقط ادمین اضافه/حذف میکنه، همه میبینن) ----
// فایل tgs (همون JSON فشرده‌شده با gzip) یا json. همیشه به صورت JSON ذخیره میشه.
const MAX_LOTTIE = 3 * 1024 * 1024;   // حجم JSON بعد از باز کردن
const MAX_LOTTIES = 500;
if (!Array.isArray(db.lotties)) db.lotties = [];
const emojiKey = (e) => String(e || '').replace(/\uFE0F/g, '').trim();
function emojiOk(raw) {
  const k = emojiKey(raw);
  if (!k || k.length > 24) return false;
  if (/[A-Za-z\s]/.test(k)) return false;
  if (!/\p{Extended_Pictographic}|\u20E3|[\u{1F1E6}-\u{1F1FF}]/u.test(k)) return false;
  if (typeof Intl !== 'undefined' && typeof Intl.Segmenter === 'function') {
    let n = 0;
    for (const _ of new Intl.Segmenter(undefined, { granularity: 'grapheme' }).segment(String(raw).trim())) n++;
    if (n !== 1) return false;
  }
  return true;
}
const publicLottie = (l) => ({ id: l.id, name: l.name, emoji: l.emoji, url: '/lotties/' + l.id + '/file', addedAt: l.addedAt });

// لیست همه‌ی لاتی‌ها (برای نمایش جای ایموجی و تب Emoji)
app.get('/lotties', auth, (_req, res) => {
  res.json(db.lotties.slice().sort((a, b) => a.addedAt - b.addedAt).map(publicLottie));
});

app.get('/lotties/:id/file', auth, (req, res) => {
  const l = db.lotties.find((x) => x.id === req.params.id);
  if (!l) return res.status(404).json({ error: 'Not found' });
  const full = path.join(FILES_DIR, l.stored);
  if (!fs.existsSync(full)) return res.status(404).json({ error: 'File is gone' });
  res.sendFile(full, { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'private, max-age=86400' } });
});

// بدنه: { name, emoji, data: base64 (tgs یا json) }
app.post('/admin/lotties', auth, adminOnly, (req, res) => {
  const emoji = typeof req.body?.emoji === 'string' ? req.body.emoji.trim() : '';
  const name = String(req.body?.name || 'lottie').replace(/[\u0000-\u001F]/g, '').trim().slice(0, 80) || 'lottie';
  const b64 = typeof req.body?.data === 'string' ? req.body.data : '';
  if (!emojiOk(emoji)) return res.status(400).json({ error: 'Choose a single emoji' });
  if (!b64 || !/^[A-Za-z0-9+/=\s]+$/.test(b64)) return res.status(400).json({ error: 'Invalid file' });
  if (db.lotties.length >= MAX_LOTTIES) return res.status(400).json({ error: 'Too many animated emojis' });
  const key = emojiKey(emoji);
  if (db.lotties.some((l) => l.key === key)) return res.status(409).json({ error: 'This emoji already has an animation. Delete it first.' });

  let raw = Buffer.from(b64, 'base64');
  if (raw.length === 0) return res.status(400).json({ error: 'Invalid file' });
  try {
    if (raw.length > 2 && raw[0] === 0x1f && raw[1] === 0x8b) raw = zlib.gunzipSync(raw, { maxOutputLength: MAX_LOTTIE }); // tgs
  } catch (_) {
    return res.status(400).json({ error: 'Could not read the TGS file (too large or corrupted)' });
  }
  if (raw.length > MAX_LOTTIE) return res.status(413).json({ error: 'File is too large (max 3 MB)' });
  let j;
  try { j = JSON.parse(raw.toString('utf8')); } catch (_) { return res.status(400).json({ error: 'This is not a valid Lottie file' }); }
  if (!j || typeof j !== 'object' || !Array.isArray(j.layers) || typeof j.fr !== 'number' || typeof j.op !== 'number') {
    return res.status(400).json({ error: 'This is not a valid Lottie file' });
  }
  const id = 'l' + crypto.randomBytes(8).toString('hex');
  const stored = id + '.json';
  try { fs.writeFileSync(path.join(FILES_DIR, stored), raw); } catch (_) { return res.status(500).json({ error: 'Could not save file' }); }
  const l = { id, name, emoji, key, stored, size: raw.length, addedBy: req.user.id, addedAt: Date.now() };
  db.lotties.push(l);
  save();
  broadcast({ type: 'lotties' });
  res.json(publicLottie(l));
});

app.delete('/admin/lotties/:id', auth, adminOnly, (req, res) => {
  const i = db.lotties.findIndex((x) => x.id === req.params.id);
  if (i < 0) return res.status(404).json({ error: 'Not found' });
  const [l] = db.lotties.splice(i, 1);
  try { fs.unlinkSync(path.join(FILES_DIR, l.stored)); } catch (_) {}
  save();
  broadcast({ type: 'lotties' });
  res.json({ ok: true });
});

// ---- گفتگوها و پیام‌ها ----
app.get('/chats', auth, (req, res) => {
  const me = req.user.id;
  const map = new Map();
  for (const m of db.messages) {
    if (m.from !== me && m.to !== me) continue;
    if (!visibleTo(m, me)) continue;
    const peerId = m.from === me ? m.to : m.from;
    let c = map.get(peerId);
    if (!c) {
      const peer = db.users.find((u) => u.id === peerId);
      if (!peer) continue;
      c = { peer: publicUser(peer), last: null, unread: 0 };
      map.set(peerId, c);
    }
    c.last = publicMsg(m, true);
    if (m.to === me && m.from !== me && !m.read) c.unread++; // پیام‌های ذخیره‌شده (Saved Messages) unread نمیشن
  }
  const list = [...map.values()].sort((a, b) => b.last.createdAt - a.last.createdAt);
  res.json(list);
});

// همه‌ی فایل‌های رد و بدل‌شده بین من و یه کاربر (برای بخش مدیا/موزیک/فایل پروفایل)
app.get('/shared/:peer', auth, (req, res) => {
  const me = req.user.id;
  const peer = parseInt(req.params.peer, 10);
  const list = db.messages
    .filter((m) => m.file && ((m.from === me && m.to === peer) || (m.from === peer && m.to === me)) && visibleTo(m, me))
    .slice(-1000)
    .reverse()
    .map((x) => publicMsg(x));
  res.json(list);
});

function markReadFrom(me, peer) {
  let changed = false;
  for (const m of db.messages) {
    if (m.from === peer && m.to === me && !m.read) { m.read = true; changed = true; }
  }
  if (changed) {
    save();
    push(peer, { type: 'read', by: me });
  }
}

app.get('/messages/:peer', auth, (req, res) => {
  const me = req.user.id;
  const peer = parseInt(req.params.peer, 10);
  const list = db.messages
    .filter((m) => ((m.from === me && m.to === peer) || (m.from === peer && m.to === me)) && visibleTo(m, me))
    .slice(-500)
    .map((x) => publicMsg(x));
  markReadFrom(me, peer);
  res.json(list);
});

app.post('/messages/:peer', auth, (req, res) => {
  const me = req.user.id;
  const peer = parseInt(req.params.peer, 10);
  if (!db.users.some((u) => u.id === peer)) return res.status(404).json({ error: 'کاربر پیدا نشد' });
  const text = typeof req.body?.text === 'string' ? req.body.text.trim() : '';
  if (!text || text.length > 4000) return res.status(400).json({ error: 'متن پیام معتبر نیست' });

  const m = { id: db.nextMsgId++, from: me, to: peer, text, createdAt: Date.now(), read: false };
  const rt = validReply(req.body?.replyTo, me, peer);
  if (rt) m.replyTo = rt;
  db.messages.push(m);
  save();
  const out = publicMsg(m);
  push(peer, { type: 'message', message: out });
  if (peer !== me) push(me, { type: 'message', message: out }); // سایر دستگاه‌های خود فرستنده
  res.json(out);
});

app.post('/read/:peer', auth, (req, res) => {
  markReadFrom(req.user.id, parseInt(req.params.peer, 10));
  res.json({ ok: true });
});

function findMsg(req, res) {
  const me = req.user.id;
  const m = db.messages.find((x) => x.id === parseInt(req.params.id, 10));
  if (!m || (m.from !== me && m.to !== me) || !visibleTo(m, me)) {
    res.status(404).json({ error: 'Message not found' });
    return null;
  }
  return m;
}

// ویرایش پیام (فقط فرستنده)
app.put('/message/:id', auth, (req, res) => {
  const m = findMsg(req, res);
  if (!m) return;
  if (m.from !== req.user.id || m.file) return res.status(403).json({ error: 'Not allowed' });
  const text = typeof req.body?.text === 'string' ? req.body.text.trim() : '';
  if (!text || text.length > 4000) return res.status(400).json({ error: 'متن پیام معتبر نیست' });
  if (text !== m.text) { m.text = text; m.edited = true; }
  save();
  const out = publicMsg(m);
  pushBoth(m, { type: 'edit', message: out });
  res.json(out);
});

// حذف پیام: ?all=1 برای همه (فقط فرستنده)، وگرنه فقط برای خودم
app.delete('/message/:id', auth, (req, res) => {
  const m = findMsg(req, res);
  if (!m) return;
  const me = req.user.id;
  if (req.query.all === '1') {
    if (m.from !== me) return res.status(403).json({ error: 'Not allowed' });
    db.messages = db.messages.filter((x) => x.id !== m.id);
    removeMsgFile(m);
    save();
    pushBoth(m, { type: 'delete', id: m.id, from: m.from, to: m.to });
  } else {
    if (!m.hiddenFor) m.hiddenFor = [];
    if (!m.hiddenFor.includes(me)) m.hiddenFor.push(me);
    save();
    push(me, { type: 'delete', id: m.id, from: m.from, to: m.to });
  }
  res.json({ ok: true });
});

// پاک کردن تاریخچه‌ی کل گفتگو (all=1 → برای هر دو طرف)
app.delete('/chat/:peer', auth, (req, res) => {
  const me = req.user.id;
  const peer = parseInt(req.params.peer, 10);
  if (!Number.isInteger(peer)) return res.status(400).json({ error: 'Invalid user' });
  const inChat = (m) => (m.from === me && m.to === peer) || (m.from === peer && m.to === me);
  const payload = { type: 'clear', from: me, to: peer };
  if (req.query.all === '1') {
    for (const m of db.messages) if (inChat(m)) removeMsgFile(m);
    db.messages = db.messages.filter((m) => !inChat(m));
    save();
    push(me, payload);
    if (peer !== me) push(peer, payload);
  } else {
    for (const m of db.messages) {
      if (!inChat(m)) continue;
      if (!m.hiddenFor) m.hiddenFor = [];
      if (!m.hiddenFor.includes(me)) m.hiddenFor.push(me);
    }
    save();
    push(me, payload);
  }
  res.json({ ok: true });
});

// پین / آن‌پین (برای هر دو طرف)
app.post('/message/:id/pin', auth, (req, res) => {
  const m = findMsg(req, res);
  if (!m) return;
  m.pinned = typeof req.body?.pinned === 'boolean' ? req.body.pinned : !m.pinned;
  save();
  const out = publicMsg(m);
  pushBoth(m, { type: 'pin', message: out });
  res.json(out);
});

// ری‌اکشن: هر کاربر روی هر پیام یک ری‌اکشن داره؛ دوباره زدن همونو برمیداره
app.post('/message/:id/react', auth, (req, res) => {
  const m = findMsg(req, res);
  if (!m) return;
  const raw = req.body?.emoji;
  let emoji = null;
  if (raw) {
    emoji = REACTIONS.find((e) => normEmoji(e) === normEmoji(raw));
    if (!emoji) return res.status(400).json({ error: 'Invalid reaction' });
  }
  if (!m.reactions) m.reactions = {};
  const me = String(req.user.id);
  if (!emoji || m.reactions[me] === emoji) delete m.reactions[me];
  else m.reactions[me] = emoji;
  save();
  const out = publicMsg(m);
  pushBoth(m, { type: 'react', message: out });
  res.json(out);
});

// ---- ارسال فایل (تا ۳۰ مگابایت) ----
// بدنه‌ی درخواست = خود فایل (stream مستقیم روی دیسک). نام و کپشن در هدرها (URL-encoded).
app.post('/messages/:peer/file', auth, (req, res) => {
  const me = req.user.id;
  const peer = parseInt(req.params.peer, 10);
  if (!db.users.some((u) => u.id === peer)) return res.status(404).json({ error: 'کاربر پیدا نشد' });

  const declared = parseInt(req.headers['content-length'] || '0', 10);
  if (declared > MAX_FILE) return res.status(413).json({ error: 'File is too large (max 30 MB)' });
  if (declared === 0 && !req.headers['transfer-encoding']) return res.status(400).json({ error: 'Empty file' });

  const dec = (v) => { try { return decodeURIComponent(String(v || '')); } catch (_) { return String(v || ''); } };
  const name = safeName(dec(req.headers['x-file-name']));
  const caption = dec(req.headers['x-caption']).trim().slice(0, 1000);
  let { kind, mime } = classify(name, String(req.headers['x-mime'] || ''));
  // ویس / ویدیو مسیج دایره‌ای (ضبط‌شده داخل اپ): kind مخصوص + مدت + شکل موج
  let recMeta = null;
  const mk = String(req.headers['x-media-kind'] || '');
  // ویدیوی بی‌صدا = گیف
  if (mk === 'gif' && kind === 'video') kind = 'gif';
  const thHeader = String(req.headers['x-thumb'] || '');
  const thumb = (['image', 'video', 'gif'].includes(kind) && /^[A-Za-z0-9+/=]{1,12000}$/.test(thHeader)) ? thHeader : null;
  if ((mk === 'voice' && kind === 'audio') || (mk === 'round' && kind === 'video')) {
    kind = mk;
    const dur = Math.max(0, Math.min(parseInt(req.headers['x-duration'] || '0', 10) || 0, 60 * 60 * 1000));
    recMeta = { duration: dur };
    const wf = String(req.headers['x-waveform'] || '');
    if (mk === 'voice' && /^[A-Za-z0-9+/=]{1,200}$/.test(wf)) recMeta.waveform = wf;
  }
  const id = crypto.randomBytes(16).toString('hex');
  const ext = path.extname(name).replace(/[^A-Za-z0-9.]/g, '').slice(0, 10);
  const stored = id + ext;
  const full = path.join(FILES_DIR, stored);

  const out = fs.createWriteStream(full);
  let size = 0;
  let failed = false;
  const fail = (code, msg) => {
    if (failed) return;
    failed = true;
    req.unpipe(out);
    out.destroy();
    fs.unlink(full, () => {});
    if (!res.headersSent) res.status(code).json({ error: msg });
    req.resume();
  };
  req.on('data', (c) => { size += c.length; if (size > MAX_FILE) fail(413, 'File is too large (max 30 MB)'); });
  req.on('aborted', () => fail(400, 'Upload aborted'));
  req.on('error', () => fail(400, 'Upload failed'));
  out.on('error', () => fail(500, 'Could not save file'));
  req.pipe(out);
  out.on('finish', async () => {
    if (failed) return;
    if (size === 0) { failed = true; fs.unlink(full, () => {}); return res.status(400).json({ error: 'Empty file' }); }
    const meta = recMeta || (kind === 'audio' ? await readAudioMeta(full, id) : null);
    const m = {
      id: db.nextMsgId++, from: me, to: peer, text: caption, createdAt: Date.now(), read: false,
      file: { name, size, mime, kind, stored, meta, ...(thumb ? { thumb } : {}) },
    };
    const rt = validReply(req.headers['x-reply-to'], me, peer);
    if (rt) m.replyTo = rt;
    db.messages.push(m);
    save();
    const o = publicMsg(m);
    push(peer, { type: 'message', message: o });
    if (peer !== me) push(me, { type: 'message', message: o });
    res.json(o);
  });
});


// ---- گیف‌های کاربر (کتابخونه‌ی شخصی) ----
const MAX_GIFS = 200;
const isGifFile = (f) => !!f && (f.kind === 'gif' || (f.kind === 'image' && f.mime === 'image/gif'));
const publicGif = (g) => ({
  id: g.id,
  name: g.name,
  size: g.size,
  mime: g.mime,
  kind: g.mime.startsWith('image/') ? 'image' : 'gif',
  url: '/me/gifs/' + g.id + '/file',
  thumb: g.thumb || null,
});

app.get('/me/gifs', auth, (req, res) => {
  const list = (req.user.gifs || []).slice().sort((a, b) => b.addedAt - a.addedAt).map(publicGif);
  res.json(list);
});

app.get('/me/gifs/:id/file', auth, (req, res) => {
  const g = (req.user.gifs || []).find((x) => x.id === req.params.id);
  if (!g) return res.status(404).json({ error: 'Not found' });
  const full = path.join(FILES_DIR, g.stored);
  if (!fs.existsSync(full)) return res.status(404).json({ error: 'File is gone' });
  res.sendFile(full, { headers: { 'Content-Type': g.mime, 'Cache-Control': 'private, max-age=86400' } });
});

// اضافه کردن گیفِ یک پیام به گیف‌های من
app.post('/me/gifs', auth, (req, res) => {
  const me = req.user;
  const mid = parseInt(req.body?.messageId, 10);
  const m = db.messages.find((x) => x.id === mid);
  if (!m || (m.from !== me.id && m.to !== me.id) || !visibleTo(m, me.id)) return res.status(404).json({ error: 'Message not found' });
  if (!isGifFile(m.file)) return res.status(400).json({ error: 'This is not a GIF' });
  if (!Array.isArray(me.gifs)) me.gifs = [];
  const dup = me.gifs.find((g) => g.src === m.id);
  if (dup) return res.json({ added: false, gif: publicGif(dup) });
  if (me.gifs.length >= MAX_GIFS) return res.status(400).json({ error: 'You can keep up to ' + MAX_GIFS + ' GIFs' });
  const src = path.join(FILES_DIR, m.file.stored);
  if (!fs.existsSync(src)) return res.status(404).json({ error: 'File is gone' });
  const id = 'g' + crypto.randomBytes(8).toString('hex');
  const stored = id + path.extname(m.file.stored);
  try { fs.copyFileSync(src, path.join(FILES_DIR, stored)); } catch (_) { return res.status(500).json({ error: 'Could not save GIF' }); }
  const g = { id, stored, name: m.file.name, size: m.file.size, mime: m.file.mime, thumb: m.file.thumb || null, src: m.id, addedAt: Date.now() };
  me.gifs.push(g);
  save();
  res.json({ added: true, gif: publicGif(g) });
});

app.delete('/me/gifs/:id', auth, (req, res) => {
  const me = req.user;
  const i = (me.gifs || []).findIndex((x) => x.id === req.params.id);
  if (i < 0) return res.status(404).json({ error: 'Not found' });
  const [g] = me.gifs.splice(i, 1);
  try { fs.unlinkSync(path.join(FILES_DIR, g.stored)); } catch (_) {}
  save();
  res.json({ ok: true });
});

// فرستادن یکی از گیف‌های من (بدون آپلود دوباره؛ فایل روی سرور کپی میشه)
app.post('/messages/:peer/gif', auth, (req, res) => {
  const me = req.user;
  const peer = parseInt(req.params.peer, 10);
  if (!db.users.some((u) => u.id === peer)) return res.status(404).json({ error: 'کاربر پیدا نشد' });
  const g = (me.gifs || []).find((x) => x.id === req.body?.gifId);
  if (!g) return res.status(404).json({ error: 'GIF not found' });
  const src = path.join(FILES_DIR, g.stored);
  if (!fs.existsSync(src)) return res.status(404).json({ error: 'File is gone' });
  const stored = crypto.randomBytes(16).toString('hex') + path.extname(g.stored);
  try { fs.copyFileSync(src, path.join(FILES_DIR, stored)); } catch (_) { return res.status(500).json({ error: 'Could not send GIF' }); }
  const kind = g.mime.startsWith('image/') ? 'image' : 'gif';
  const m = {
    id: db.nextMsgId++, from: me.id, to: peer, text: '', createdAt: Date.now(), read: false,
    file: { name: g.name, size: g.size, mime: g.mime, kind, stored, meta: null, ...(g.thumb ? { thumb: g.thumb } : {}) },
  };
  const rt = validReply(req.body?.replyTo, me.id, peer);
  if (rt) m.replyTo = rt;
  db.messages.push(m);
  save();
  const o = publicMsg(m);
  push(peer, { type: 'message', message: o });
  if (peer !== me.id) push(me.id, { type: 'message', message: o });
  res.json(o);
});

// ---------------------------------------------------------------------------
// ---- بات Sticker: ساخت گیف از ویدیو + پک ایموجی‌های متحرک کاستوم ----
// ---------------------------------------------------------------------------
const { execFile } = require('child_process');
const MAX_PACK_ITEMS = 120;
const MAX_MY_PACKS = 100;
const MAX_OWN_PACKS = 30;
if (!Array.isArray(db.packs)) db.packs = [];
if (!db.packDrafts || typeof db.packDrafts !== 'object') db.packDrafts = {};
for (const u of db.users) if (!Array.isArray(u.packs)) u.packs = [];

const findPack = (id) => db.packs.find((p) => p.id === id);
function findPackItem(itemId) {
  for (const p of db.packs) {
    const it = p.items.find((x) => x.id === itemId);
    if (it) return { pack: p, item: it };
  }
  return null;
}
const publicPack = (p, me) => ({
  id: p.id,
  title: p.title,
  ownerId: p.ownerId,
  owner: (db.users.find((u) => u.id === p.ownerId) || {}).username || null,
  count: p.items.length,
  createdAt: p.createdAt,
  added: !!me && (me.packs || []).includes(p.id),
  mine: !!me && p.ownerId === me.id,
  link: 'chatapp://emoji/' + p.id,
  items: p.items.map((it) => ({ id: it.id, emoji: it.emoji })),
});
const publicDraft = (d) => (d ? { title: d.title, count: d.items.length, items: d.items.map((i) => ({ id: i.id, emoji: i.emoji })) } : null);

function dropDraft(uid) {
  const d = db.packDrafts[uid];
  if (!d) return;
  for (const it of d.items) { try { fs.unlinkSync(path.join(FILES_DIR, it.stored)); } catch (_) {} }
  delete db.packDrafts[uid];
}

// tgs (gzip) یا json → JSON خام؛ خطا = { code, error }
function parseLottie(b64) {
  if (typeof b64 !== 'string' || !b64 || !/^[A-Za-z0-9+/=\s]+$/.test(b64)) return { code: 400, error: 'Invalid file' };
  let raw = Buffer.from(b64, 'base64');
  if (raw.length === 0) return { code: 400, error: 'Invalid file' };
  try {
    if (raw.length > 2 && raw[0] === 0x1f && raw[1] === 0x8b) raw = zlib.gunzipSync(raw); // بدون محدودیت حجم
  } catch (_) {
    return { code: 400, error: 'Could not read the TGS file (corrupted)' };
  }
  let j;
  try { j = JSON.parse(raw.toString('utf8')); } catch (_) { return { code: 400, error: 'This is not a valid Lottie file' }; }
  if (!j || typeof j !== 'object' || !Array.isArray(j.layers) || typeof j.fr !== 'number' || typeof j.op !== 'number') {
    return { code: 400, error: 'This is not a valid Lottie file' };
  }
  return { raw };
}

// --- پیش‌نویس پک (هر کاربر یکی) ---
app.get('/packs/draft', auth, (req, res) => {
  res.json({ draft: publicDraft(db.packDrafts[req.user.id]) });
});

// شروع پک جدید (پیش‌نویس قبلی پاک میشه)
app.post('/packs/draft', auth, (req, res) => {
  const title = String(req.body?.title || '').replace(/[\u0000-\u001F]/g, ' ').trim().slice(0, 60);
  if (!title) return res.status(400).json({ error: 'Send a name for the pack' });
  dropDraft(req.user.id);
  db.packDrafts[req.user.id] = { title, items: [], createdAt: Date.now() };
  save();
  res.json({ draft: publicDraft(db.packDrafts[req.user.id]) });
});

// اضافه کردن یک ایموجی (فایل tgs + ایموجی) به پیش‌نویس. بدنه: { emoji, data: base64 }
app.post('/packs/draft/item', auth, (req, res) => {
  const d = db.packDrafts[req.user.id];
  if (!d) return res.status(404).json({ error: 'No pack in progress. Send /new_pack first' });
  if (d.items.length >= MAX_PACK_ITEMS) return res.status(400).json({ error: 'A pack can hold up to ' + MAX_PACK_ITEMS + ' emoji. Send /publish' });
  const emoji = typeof req.body?.emoji === 'string' ? req.body.emoji.trim() : '';
  if (!emojiOk(emoji)) return res.status(400).json({ error: 'Send exactly one emoji' });
  const r = parseLottie(req.body?.data);
  if (r.error) return res.status(r.code).json({ error: r.error });
  const id = 'e' + crypto.randomBytes(5).toString('hex');
  const stored = 'ce_' + id + '.json';
  try { fs.writeFileSync(path.join(FILES_DIR, stored), r.raw); } catch (_) { return res.status(500).json({ error: 'Could not save file' }); }
  d.items.push({ id, emoji, stored, size: r.raw.length });
  save();
  res.json({ item: { id, emoji }, count: d.items.length });
});

// ساخت پک از چیزهایی که تا الان فرستاده و تایید شدن
app.post('/packs/draft/publish', auth, (req, res) => {
  const me = req.user;
  const d = db.packDrafts[me.id];
  if (!d) return res.status(404).json({ error: 'No pack in progress. Send /new_pack first' });
  if (d.items.length === 0) return res.status(400).json({ error: 'Add at least one emoji before publishing' });
  if (db.packs.filter((p) => p.ownerId === me.id).length >= MAX_OWN_PACKS) return res.status(400).json({ error: 'You can create up to ' + MAX_OWN_PACKS + ' packs' });
  let id;
  do { id = crypto.randomBytes(4).toString('hex'); } while (findPack(id));
  const pack = { id, title: d.title, ownerId: me.id, items: d.items, createdAt: Date.now() };
  db.packs.push(pack);
  delete db.packDrafts[me.id];
  if (!Array.isArray(me.packs)) me.packs = [];
  me.packs.push(id);
  save();
  push(me.id, { type: 'packs' });
  res.json(publicPack(pack, me));
});

app.delete('/packs/draft', auth, (req, res) => {
  dropDraft(req.user.id);
  save();
  res.json({ ok: true });
});

// --- پک‌های اکانت من ---
app.get('/me/packs', auth, (req, res) => {
  const me = req.user;
  res.json((me.packs || []).map(findPack).filter(Boolean).map((p) => publicPack(p, me)));
});

app.post('/me/packs/:id', auth, (req, res) => {
  const me = req.user;
  const p = findPack(req.params.id);
  if (!p) return res.status(404).json({ error: 'Pack not found' });
  if (!Array.isArray(me.packs)) me.packs = [];
  if (!me.packs.includes(p.id)) {
    if (me.packs.length >= MAX_MY_PACKS) return res.status(400).json({ error: 'You can add up to ' + MAX_MY_PACKS + ' packs' });
    me.packs.push(p.id);
    save();
    push(me.id, { type: 'packs' });
  }
  res.json(publicPack(p, me));
});

app.delete('/me/packs/:id', auth, (req, res) => {
  const me = req.user;
  me.packs = (me.packs || []).filter((x) => x !== req.params.id);
  save();
  push(me.id, { type: 'packs' });
  res.json({ ok: true });
});

// --- اطلاعات پک (برای لینک) و حذف توسط سازنده ---
app.get('/packs/:id', auth, (req, res) => {
  const p = findPack(req.params.id);
  if (!p) return res.status(404).json({ error: 'Pack not found' });
  res.json(publicPack(p, req.user));
});

app.delete('/packs/:id', auth, (req, res) => {
  const i = db.packs.findIndex((x) => x.id === req.params.id);
  if (i < 0) return res.status(404).json({ error: 'Pack not found' });
  const p = db.packs[i];
  if (p.ownerId !== req.user.id && !req.user.isAdmin) return res.status(403).json({ error: 'Only the creator can delete this pack' });
  db.packs.splice(i, 1);
  for (const it of p.items) { try { fs.unlinkSync(path.join(FILES_DIR, it.stored)); } catch (_) {} }
  for (const u of db.users) if (Array.isArray(u.packs)) u.packs = u.packs.filter((x) => x !== p.id);
  save();
  broadcast({ type: 'packs' });
  res.json({ ok: true });
});

// خود انیمیشن یک ایموجی کاستوم (برای هر کاربر واردشده؛ تا پیام‌های بقیه هم درست نشون داده بشه)
app.get('/cemoji/:id/file', auth, (req, res) => {
  const f = findPackItem(req.params.id);
  if (!f) return res.status(404).json({ error: 'Not found' });
  const full = path.join(FILES_DIR, f.item.stored);
  if (!fs.existsSync(full)) return res.status(404).json({ error: 'File is gone' });
  res.sendFile(full, { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'private, max-age=86400' } });
});

// --- ساخت گیف از ویدیو (بات Sticker: /new_gif) ---
// بدنه = خود ویدیو. اگه ffmpeg روی سرور باشه بی‌صدا + سبک (حداکثر ۲۰ ثانیه، ۴۸۰ پیکسل) میشه؛
// وگرنه همون ویدیو نگه داشته میشه (اپ موقع پخش گیف صداش رو قطع میکنه). نتیجه تو «گیف‌های من» ذخیره میشه.
app.post('/sticker/gif', auth, (req, res) => {
  const me = req.user;
  const declared = parseInt(req.headers['content-length'] || '0', 10);
  if (declared > MAX_FILE) return res.status(413).json({ error: 'File is too large (max 30 MB)' });
  if (declared === 0 && !req.headers['transfer-encoding']) return res.status(400).json({ error: 'Empty file' });
  if (!Array.isArray(me.gifs)) me.gifs = [];
  if (me.gifs.length >= MAX_GIFS) return res.status(400).json({ error: 'You can keep up to ' + MAX_GIFS + ' GIFs' });

  const dec = (v) => { try { return decodeURIComponent(String(v || '')); } catch (_) { return String(v || ''); } };
  const name = safeName(dec(req.headers['x-file-name']));
  const { kind, mime } = classify(name, String(req.headers['x-mime'] || ''));
  const isGifImg = kind === 'image' && mime === 'image/gif';
  if (kind !== 'video' && !isGifImg) return res.status(400).json({ error: 'Please send a video file' });

  const id = 'g' + crypto.randomBytes(8).toString('hex');
  const ext = (path.extname(name).replace(/[^A-Za-z0-9.]/g, '').slice(0, 10)) || (isGifImg ? '.gif' : '.mp4');
  const srcStored = id + '.src' + ext;
  const srcFull = path.join(FILES_DIR, srcStored);
  const out = fs.createWriteStream(srcFull);
  let size = 0;
  let failed = false;
  const fail = (code, msg) => {
    if (failed) return;
    failed = true;
    req.unpipe(out);
    out.destroy();
    fs.unlink(srcFull, () => {});
    if (!res.headersSent) res.status(code).json({ error: msg });
    req.resume();
  };
  req.on('data', (c) => { size += c.length; if (size > MAX_FILE) fail(413, 'File is too large (max 30 MB)'); });
  req.on('aborted', () => fail(400, 'Upload aborted'));
  req.on('error', () => fail(400, 'Upload failed'));
  out.on('error', () => fail(500, 'Could not save file'));
  req.pipe(out);
  out.on('finish', () => {
    if (failed) return;
    if (size === 0) { failed = true; fs.unlink(srcFull, () => {}); return res.status(400).json({ error: 'Empty file' }); }
    const base = name.replace(/\.[^.]+$/, '') || 'gif';
    const finish = (stored, outMime, outName) => {
      let st = { size: 0 };
      try { st = fs.statSync(path.join(FILES_DIR, stored)); } catch (_) {}
      const g = { id, stored, name: outName, size: st.size, mime: outMime, thumb: null, src: null, addedAt: Date.now() };
      me.gifs.push(g);
      save();
      res.json(publicGif(g));
    };
    const keepOriginal = () => {
      const stored = id + ext;
      try { fs.renameSync(srcFull, path.join(FILES_DIR, stored)); } catch (_) { fs.unlink(srcFull, () => {}); return res.status(500).json({ error: 'Could not save GIF' }); }
      finish(stored, mime, name);
    };
    if (isGifImg) return keepOriginal();
    const outStored = id + '.mp4';
    const outFull = path.join(FILES_DIR, outStored);
    const args = ['-y', '-i', srcFull, '-t', '20', '-an',
      '-vf', 'scale=trunc(min(480\\,iw)/2)*2:-2,fps=24',
      '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '27', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', outFull];
    execFile('ffmpeg', args, { timeout: 120000 }, (err) => {
      let ok = false;
      try { ok = !err && fs.statSync(outFull).size > 0; } catch (_) {}
      if (ok) {
        fs.unlink(srcFull, () => {});
        return finish(outStored, 'video/mp4', base + '.mp4');
      }
      fs.unlink(outFull, () => {});
      keepOriginal();
    });
  });
});

// دانلود / استریم فایل (فقط فرستنده و گیرنده؛ از Range پشتیبانی میکنه تا پلیر بتونه seek کنه)
app.get('/file/:id', auth, (req, res) => {
  const m = findMsg(req, res);
  if (!m) return;
  if (!m.file) return res.status(404).json({ error: 'Not found' });
  const full = path.join(FILES_DIR, m.file.stored);
  if (!fs.existsSync(full)) return res.status(404).json({ error: 'File is gone' });
  res.sendFile(full, {
    headers: {
      'Content-Type': m.file.mime,
      'Content-Disposition': `inline; filename*=UTF-8''${encodeURIComponent(m.file.name)}`,
      'Cache-Control': 'private, max-age=86400',
    },
  });
});

// ---- راه‌اندازی ----
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

wss.on('connection', (ws, req) => {
  let uid;
  try {
    const token = new URL(req.url, 'http://x').searchParams.get('token');
    uid = jwt.verify(token, SECRET).uid;
  } catch (_) {
    ws.close(4001, 'unauthorized');
    return;
  }
  const user = db.users.find((x) => x.id === uid);
  if (!user) { ws.close(4001, 'unauthorized'); return; }

  ws.isAlive = true;
  ws.on('pong', () => { ws.isAlive = true; });
  const wasOffline = !sockets.has(uid);
  if (wasOffline) sockets.set(uid, new Set());
  sockets.get(uid).add(ws);
  try { ws.send(JSON.stringify({ type: 'hello' })); } catch (_) {}
  if (wasOffline) {
    user.lastSeen = Date.now();
    broadcast({ type: 'user', user: publicUser(user) });
  }
  ws.on('close', () => {
    const set = sockets.get(uid);
    if (set) {
      set.delete(ws);
      if (!set.size) {
        sockets.delete(uid);
        user.lastSeen = Date.now();
        save();
        broadcast({ type: 'user', user: publicUser(user) });
      }
    }
  });
  ws.on('error', () => {});
});

setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) { ws.terminate(); continue; }
    ws.isAlive = false;
    ws.ping();
  }
}, 30000);

server.listen(PORT, '0.0.0.0', () => console.log(`Chat server on port ${PORT}`));
