import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'admin_page.dart';
import 'api.dart';
import 'attheme.dart';
import 'login_page.dart';
import 'permissions_page.dart';
import 'profile_page.dart';
import 'utils.dart';

/// کلید اسکفولد صفحه‌ی اصلی؛ دکمه‌ی همبرگری چت‌ها باهاش منو رو باز می‌کنه
final GlobalKey<ScaffoldState> shellKey = GlobalKey<ScaffoldState>();

/// منوی کشویی کنار (شبیه تلگرام): هدر پروفایل، دکمه‌ی ماه، لیست حساب‌ها و آیتم‌ها
class TgDrawer extends StatefulWidget {
  final Future<void> Function(Account a) onSwitch;
  final VoidCallback onOpenSettings;
  const TgDrawer({super.key, required this.onSwitch, required this.onOpenSettings});

  @override
  State<TgDrawer> createState() => _TgDrawerState();
}

class _TgDrawerState extends State<TgDrawer> {
  bool _accountsOpen = false;

  @override
  void initState() {
    super.initState();
    Api.meTick.addListener(_onMe);
  }

  @override
  void dispose() {
    Api.meTick.removeListener(_onMe);
    super.dispose();
  }

  void _onMe() {
    if (mounted) setState(() {});
  }

  Future<void> _toggleTheme() async {
    final toLight = context.dark;
    if (AtTheme.current.value != null) await AtTheme.remove();
    await Api.setTheme(toLight ? ThemeMode.light : ThemeMode.dark);
  }

  /// اول منو رو می‌بنده، بعد کار رو انجام میده
  void _go(void Function(NavigatorState nav) action) {
    final nav = Navigator.of(context);
    nav.pop();
    action(nav);
  }

  Widget _header() {
    final me = Api.me ?? {'id': Api.userId ?? 0, 'username': Api.username ?? ''};
    final username = (me['username'] as String?) ?? Api.username ?? '';
    final full = displayNameOf(me, fallback: username);
    final dark = context.dark;
    return Container(
      width: double.infinity,
      color: dark ? const Color(0xFF232E3C) : tgBlue,
      padding: EdgeInsets.fromLTRB(16, MediaQuery.of(context).padding.top + 16, 8, 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Avatar.fromUser(me, size: 64),
              const Spacer(),
              IconButton(
                onPressed: _toggleTheme,
                icon: Icon(dark ? CupertinoIcons.sun_max_fill : CupertinoIcons.moon_fill, color: Colors.white, size: 24),
              ),
            ],
          ),
          const SizedBox(height: 10),
          InkWell(
            onTap: () => setState(() => _accountsOpen = !_accountsOpen),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(0, 4, 8, 8),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(full,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            textDirection: dirOf(full),
                            style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 2),
                        Text('@$username',
                            textDirection: TextDirection.ltr,
                            style: const TextStyle(color: Colors.white70, fontSize: 14)),
                      ],
                    ),
                  ),
                  AnimatedRotation(
                    turns: _accountsOpen ? 0.5 : 0,
                    duration: const Duration(milliseconds: 200),
                    child: const Icon(CupertinoIcons.chevron_down, color: Colors.white, size: 18),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _item(IconData icon, String label, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        child: Row(
          children: [
            Icon(icon, size: 23, color: context.subText),
            const SizedBox(width: 24),
            Expanded(child: Text(label, style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w500))),
          ],
        ),
      ),
    );
  }

  Widget _accountRow(Account a) {
    final mineNow = a.id == Api.userId;
    return InkWell(
      onTap: () {
        Navigator.of(context).pop();
        widget.onSwitch(a);
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(
          children: [
            Avatar(id: a.id, name: a.username, size: 36, url: mineNow ? (Api.me?['avatar'] as String?) : null),
            const SizedBox(width: 16),
            Expanded(child: Text(a.username, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 15.5))),
            if (mineNow) Icon(CupertinoIcons.check_mark, size: 18, color: tgBlue),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: context.cardBg,
      width: 290,
      shape: const RoundedRectangleBorder(),
      child: Column(
        children: [
          _header(),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.only(top: 4),
              children: [
                if (_accountsOpen) ...[
                  for (final a in Api.accounts) _accountRow(a),
                  InkWell(
                    onTap: () => _go((nav) => nav.push(MaterialPageRoute(builder: (_) => const LoginPage(addingAccount: true)))),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: Row(
                        children: [
                          Container(
                            width: 36,
                            height: 36,
                            decoration: BoxDecoration(shape: BoxShape.circle, color: tgBlue.withOpacity(0.15)),
                            child: Icon(CupertinoIcons.plus, size: 18, color: tgBlue),
                          ),
                          const SizedBox(width: 16),
                          Text('Add account', style: TextStyle(fontSize: 15.5, color: tgBlue, fontWeight: FontWeight.w500)),
                        ],
                      ),
                    ),
                  ),
                  const Divider(height: 12, thickness: 0.6),
                ],
                _item(CupertinoIcons.person_circle, 'My Profile', () {
                  _go((nav) => nav.push(MaterialPageRoute(
                        builder: (_) => ProfilePage(userId: Api.userId ?? 0, initial: Api.me),
                      )));
                }),
                _item(CupertinoIcons.settings, 'Settings', () {
                  Navigator.of(context).pop();
                  widget.onOpenSettings();
                }),
                _item(CupertinoIcons.shield, 'Permissions',
                    () => _go((nav) => nav.push(MaterialPageRoute(builder: (_) => const PermissionsPage())))),
                if (Api.isAdmin)
                  _item(CupertinoIcons.lock_shield, 'Admin panel',
                      () => _go((nav) => nav.push(MaterialPageRoute(builder: (_) => const AdminPage())))),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
