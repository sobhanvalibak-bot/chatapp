import 'dart:async';
import 'dart:ui';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:package_info_plus/package_info_plus.dart';

import 'admin_page.dart';
import 'api.dart';
import 'attheme.dart';
import 'home_page.dart';
import 'login_page.dart';
import 'permissions_page.dart';
import 'player.dart';
import 'profile_page.dart';
import 'tg_drawer.dart';
import 'utils.dart';

/// صفحه‌ی اصلی: نوار شناور پایین با دو تب Chats / Settings + منوی کشویی کنار
class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _tab = 0; // Chats
  StreamSubscription? _sub;

  @override
  void initState() {
    super.initState();
    _loadMe();
    _sub = Api.events.listen((e) {
      if (!mounted) return;
      if (e['type'] == 'user') {
        final u = e['user'];
        if (u is Map && u['id'] == Api.userId) {
          Api.me = Map<String, dynamic>.from(u);
          setState(() {});
        }
      }
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _loadMe() async {
    try {
      await Api.refreshMe();
      if (mounted) setState(() {});
    } catch (_) {}
  }

  Future<void> _switchTo(Account a) async {
    if (a.id == Api.userId) return;
    await AudioCtl.i.close();
    await Api.switchTo(a);
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const MainShell()),
      (r) => false,
    );
  }

  Widget _tabItem({
    required int index,
    required String label,
    required Widget icon,
    VoidCallback? onLong,
  }) {
    final on = _tab == index;
    final color = on ? tgBlue : (context.dark ? const Color(0xFFC5D0DC) : Colors.black54);
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => setState(() => _tab = index),
        onLongPress: onLong,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          decoration: BoxDecoration(
            color: on ? tgBlue.withOpacity(0.2) : Colors.transparent,
            borderRadius: BorderRadius.circular(28),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 26, child: Center(child: icon)),
              const SizedBox(height: 2),
              Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: color)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _bar() {
    final dark = context.dark;
    final bottom = MediaQuery.of(context).padding.bottom;
    return Positioned(
      left: 18,
      right: 18,
      bottom: 14 + bottom,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(32),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 22, sigmaY: 22),
          child: Container(
            height: 64,
            padding: const EdgeInsets.all(5),
            decoration: BoxDecoration(
              color: dark ? const Color(0xB31C2733) : const Color(0xCCFFFFFF),
              borderRadius: BorderRadius.circular(32),
              border: Border.all(color: dark ? Colors.white12 : Colors.black12, width: 0.8),
            ),
            child: Row(
              children: [
                _tabItem(
                  index: 0,
                  label: 'Chats',
                  icon: Icon(CupertinoIcons.chat_bubble_2_fill,
                      size: 24, color: _tab == 0 ? tgBlue : (dark ? const Color(0xFFC5D0DC) : Colors.black54)),
                ),
                _tabItem(
                  index: 1,
                  label: 'Settings',
                  icon: Icon(CupertinoIcons.settings,
                      size: 24, color: _tab == 1 ? tgBlue : (dark ? const Color(0xFFC5D0DC) : Colors.black54)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: shellKey,
      drawer: TgDrawer(
        onSwitch: _switchTo,
        onOpenSettings: () => setState(() => _tab = 1),
      ),
      body: Stack(
        children: [
          IndexedStack(
            index: _tab,
            children: const [
              HomePage(),
              _SettingsTab(),
            ],
          ),
          _bar(),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// تب Settings: ویرایش اسم، فامیلی، یوزرنیم، بیو و عکس پروفایل
// ---------------------------------------------------------------------------
class _Field {
  final String label;
  final String value;
  final int maxLen;
  final int lines;
  final String? prefix;
  final bool ltr;
  const _Field(this.label, this.value, {this.maxLen = 40, this.lines = 1, this.prefix, this.ltr = false});
}

class _SettingsTab extends StatefulWidget {
  const _SettingsTab();

  @override
  State<_SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<_SettingsTab> {
  String _version = '';

  void _snack(String t) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));
  }

  /// انتخاب فایل .attheme از حافظه و اعمالش
  Future<void> _importTheme() async {
    try {
      final r = await FilePicker.platform.pickFiles(type: FileType.any, withData: true);
      if (r == null || r.files.isEmpty) return;
      final f = r.files.first;
      final bytes = f.bytes;
      if (bytes == null) {
        _snack('Could not read the file');
        return;
      }
      final ok = await AtTheme.applyBytes(bytes, f.name);
      if (mounted) setState(() {});
      _snack(ok ? 'Theme applied' : 'This is not a valid .attheme file');
    } catch (_) {
      _snack('Could not import the theme');
    }
  }

  void _themeMenu() {
    showCupertinoModalPopup(
      context: context,
      builder: (ctx) {
        Widget item(String label, ThemeMode m) => CupertinoActionSheetAction(
              onPressed: () {
                Navigator.pop(ctx);
                if (AtTheme.current.value != null) AtTheme.remove();
                Api.setTheme(m);
              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(label),
                  if (Api.themeMode.value == m && AtTheme.current.value == null) ...[
                    const SizedBox(width: 8),
                    const Icon(CupertinoIcons.check_mark, size: 18),
                  ],
                ],
              ),
            );
        return CupertinoActionSheet(
          title: const Text('Appearance'),
          actions: [
            item('Light', ThemeMode.light),
            item('Dark', ThemeMode.dark),
            item('System default', ThemeMode.system),
            CupertinoActionSheetAction(
              onPressed: () {
                Navigator.pop(ctx);
                _importTheme();
              },
              child: Text(AtTheme.current.value == null
                  ? 'Import theme (.attheme)'
                  : 'Import another theme (.attheme)'),
            ),
            if (AtTheme.current.value != null)
              CupertinoActionSheetAction(
                isDestructiveAction: true,
                onPressed: () async {
                  Navigator.pop(ctx);
                  await AtTheme.remove();
                  if (mounted) setState(() {});
                },
                child: Text('Remove "${AtTheme.current.value!.name}"'),
              ),
          ],
          cancelButton: CupertinoActionSheetAction(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
        );
      },
    );
  }


  @override
  void initState() {
    super.initState();
    _loadVersion();
    Api.meTick.addListener(_onMe);
    Api.refreshMe().catchError((_) => <String, dynamic>{});
  }

  @override
  void dispose() {
    Api.meTick.removeListener(_onMe);
    super.dispose();
  }

  void _onMe() {
    if (mounted) setState(() {});
  }

  Future<void> _loadVersion() async {
    try {
      final i = await PackageInfo.fromPlatform();
      if (mounted) setState(() => _version = 'Version ${i.version} (build ${i.buildNumber})');
    } catch (_) {
      if (mounted) setState(() => _version = 'Version 1.0.0');
    }
  }

  Future<void> _prompt(String title, List<_Field> fields, Future<void> Function(List<String>) onSave) async {
    final ctrls = [for (final f in fields) TextEditingController(text: f.value)];
    String? err;
    bool busy = false;
    await showDialog<bool>(
      context: context,
      builder: (dctx) => StatefulBuilder(
        builder: (dctx, setD) => AlertDialog(
          title: Text(title),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (var i = 0; i < fields.length; i++)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: TextField(
                      controller: ctrls[i],
                      autofocus: i == 0,
                      maxLength: fields[i].maxLen,
                      minLines: fields[i].lines,
                      maxLines: fields[i].lines > 1 ? 5 : 1,
                      autocorrect: !fields[i].ltr,
                      textDirection: fields[i].ltr ? TextDirection.ltr : null,
                      decoration: InputDecoration(labelText: fields[i].label, prefixText: fields[i].prefix),
                    ),
                  ),
                if (err != null)
                  Text(err!, style: const TextStyle(color: Color(0xFFE53935), fontSize: 13)),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: busy ? null : () => Navigator.of(dctx).pop(false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: busy
                  ? null
                  : () async {
                      setD(() {
                        busy = true;
                        err = null;
                      });
                      try {
                        await onSave([for (final c in ctrls) c.text.trim()]);
                        if (dctx.mounted) Navigator.of(dctx).pop(true);
                      } on ApiException catch (e) {
                        setD(() {
                          busy = false;
                          err = e.message;
                        });
                      }
                    },
              child: const Text('Save', style: TextStyle(fontWeight: FontWeight.w600)),
            ),
          ],
        ),
      ),
    );
    for (final c in ctrls) {
      c.dispose();
    }
    try {
      await Api.refreshMe();
    } catch (_) {}
    if (mounted) setState(() {});
  }

  void _editName() {
    final me = Api.me ?? {};
    _prompt(
      'Name',
      [
        _Field('First name', (me['firstName'] as String?) ?? ''),
        _Field('Last name', (me['lastName'] as String?) ?? ''),
      ],
      (v) async {
        await Api.updateProfile(firstName: v[0], lastName: v[1]);
      },
    );
  }

  void _editUsername() {
    final me = Api.me ?? {};
    final cur = (me['username'] as String?) ?? Api.username ?? '';
    _prompt(
      'Username',
      [_Field('Username', cur, maxLen: 32, prefix: '@', ltr: true)],
      (v) async {
        if (v[0].isEmpty) throw ApiException('Username cannot be empty');
        if (v[0] != cur) await Api.updateProfile(username: v[0]);
      },
    );
  }

  void _editBio() {
    final me = Api.me ?? {};
    _prompt(
      'Bio',
      [_Field('Bio', (me['bio'] as String?) ?? '', maxLen: 200, lines: 3)],
      (v) async {
        await Api.updateProfile(bio: v[0]);
      },
    );
  }

  Future<void> _openEditPage() async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ProfileEditPage()));
    try {
      await Api.refreshMe();
    } catch (_) {}
    if (mounted) setState(() {});
  }

  // ---------------------------------------------------------------- ظاهر تلگرامی
  Widget _gap() => Container(height: 12, color: context.chatBg);

  Widget _title(String t) => Container(
        color: context.cardBg,
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 4),
        child: Text(t, style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600, color: tgBlue)),
      );

  /// آیتم حساب: مقدار بالا، عنوان پایین، بدون آیکن (مثل تنظیمات تلگرام)
  Widget _acc(String label, String value, VoidCallback onTap) {
    return Material(
      color: context.cardBg,
      child: InkWell(
        onTap: onTap,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  textDirection: dirOf(value),
                  style: const TextStyle(fontSize: 16)),
              const SizedBox(height: 2),
              Text(label, style: TextStyle(fontSize: 13, color: context.subText)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _row(IconData icon, String label, VoidCallback onTap, {Color? color, String? trailing}) {
    return Material(
      color: context.cardBg,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          child: Row(
            children: [
              Icon(icon, size: 23, color: color ?? context.subText),
              const SizedBox(width: 24),
              Expanded(child: Text(label, style: TextStyle(fontSize: 15.5, color: color))),
              if (trailing != null) Text(trailing, style: TextStyle(color: context.subText, fontSize: 14)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _header(Map me, String full) {
    final dark = context.dark;
    final top = MediaQuery.of(context).padding.top;
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          width: double.infinity,
          color: dark ? const Color(0xFF232E3C) : tgBlue,
          padding: EdgeInsets.fromLTRB(16, top + 14, 16, 18),
          child: Row(
            children: [
              GestureDetector(onTap: _openEditPage, child: Avatar.fromUser(Map<String, dynamic>.from(me), size: 72)),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(full,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textDirection: dirOf(full),
                        style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 3),
                    const Text('online', style: TextStyle(color: Colors.white70, fontSize: 14)),
                  ],
                ),
              ),
              const SizedBox(width: 56),
            ],
          ),
        ),
        Positioned(
          right: 16,
          bottom: -26,
          child: Material(
            color: dark ? tgBlue : Colors.white,
            shape: const CircleBorder(),
            elevation: 4,
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: _openEditPage,
              child: SizedBox(
                width: 54,
                height: 54,
                child: Icon(CupertinoIcons.camera_fill, color: dark ? Colors.white : tgBlue, size: 24),
              ),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final me = Api.me ?? {'id': Api.userId ?? 0, 'username': Api.username ?? ''};
    final username = (me['username'] as String?) ?? Api.username ?? '';
    final full = displayNameOf(me, fallback: username);
    final first = ((me['firstName'] as String?) ?? '').trim();
    final last = ((me['lastName'] as String?) ?? '').trim();
    final nameValue = '$first $last'.trim();
    final bio = ((me['bio'] as String?) ?? '').trim();
    final themeLabel = AtTheme.current.value != null
        ? AtTheme.current.value!.name
        : Api.themeMode.value == ThemeMode.dark
            ? 'Dark'
            : (Api.themeMode.value == ThemeMode.light ? 'Light' : 'System');
    return ListView(
      padding: const EdgeInsets.only(bottom: 110),
      children: [
        _header(me, full),
        Container(height: 30, color: context.cardBg),
        _title('Account'),
        _acc('Name', nameValue.isEmpty ? 'Not set' : nameValue, _editName),
        _acc('Username', '@$username', _editUsername),
        _acc('Bio', bio.isEmpty ? 'Add a few words about yourself' : bio, _editBio),
        const SizedBox(height: 6),
        _gap(),
        _title('Settings'),
        _row(CupertinoIcons.pencil, 'Edit Profile', _openEditPage),
        _row(CupertinoIcons.paintbrush, 'Appearance', _themeMenu, trailing: themeLabel),
        _row(CupertinoIcons.shield, 'Permissions',
            () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PermissionsPage()))),
        _row(CupertinoIcons.globe, 'Server address', () async {
          await showServerDialog(context);
        }),
        if (Api.isAdmin)
          _row(CupertinoIcons.lock_shield, 'Admin panel',
              () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AdminPage()))),
        _gap(),
        _row(CupertinoIcons.square_arrow_right, 'Log out @$username', () async {
          await AudioCtl.i.close();
          await Api.logout();
          if (!mounted) return;
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => Api.loggedIn ? const MainShell() : const LoginPage()),
            (r) => false,
          );
        }, color: const Color(0xFFFF5A52)),
        Padding(
          padding: const EdgeInsets.only(top: 22),
          child: Center(child: Text(_version, style: TextStyle(fontSize: 13.5, color: context.subText))),
        ),
      ],
    );
  }
}
